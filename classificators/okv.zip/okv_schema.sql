CREATE TABLE class_currency (
  id smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'pk',
  `name` varchar(255) NOT NULL COMMENT 'Наименование валюты',
  number_code varchar(10) NOT NULL COMMENT 'Числовой код',
  char_code varchar(10) NOT NULL COMMENT 'Буквенный код',
  countries text COMMENT 'Страны, где используется',
  `comment` varchar(255) DEFAULT NULL COMMENT 'Комментарий',
  visible tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (id),
  UNIQUE KEY number_code (number_code),
  UNIQUE KEY char_code (char_code),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Классификатор валют';