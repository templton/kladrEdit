CREATE TABLE class_okp (
  id int(11) NOT NULL AUTO_INCREMENT COMMENT 'pk',
  `code` varchar(16) NOT NULL COMMENT 'Код',
  `name` varchar(512) NOT NULL COMMENT 'Наименование',
  control_number smallint(16) NOT NULL COMMENT 'Контрольное число',
  parent_id int(11) DEFAULT NULL COMMENT 'Вышестоящий класс',
  parent_code varchar(16) DEFAULT NULL COMMENT 'Код вышестоящего класса',
  node_count smallint(6) NOT NULL DEFAULT '0' COMMENT 'Количество элементов в ветке',
  PRIMARY KEY (id),
  UNIQUE KEY `code` (`code`),
  KEY parent_id (parent_id)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='ОК продукции';


ALTER TABLE `class_okp`
  ADD CONSTRAINT class_okp_ibfk_1 FOREIGN KEY (parent_id) REFERENCES class_okp (id);
