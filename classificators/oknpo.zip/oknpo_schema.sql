CREATE TABLE class_oknpo (
  id int(11) NOT NULL auto_increment COMMENT 'PK',
  `name` varchar(512) NOT NULL COMMENT 'Наименование групп профессий и специальностей,  профессий, специальностей',
  `code` varchar(20) NOT NULL COMMENT 'Код',
  education_level tinyint(4) default NULL COMMENT 'Уровень начального профессионального образования по профессии',
  control_number tinyint(4) default NULL COMMENT 'Контрольное число',
  parent_id int(11) default NULL COMMENT 'Вышестоящий объект',
  parent_code varchar(20) default NULL COMMENT 'Код вышестоящего объекта',
  node_count smallint(6) NOT NULL default '0' COMMENT 'Количество вложенных в текущую ветку',
  msko_code varchar(6) default NULL COMMENT 'Код МСКО',
  PRIMARY KEY  (id),
  KEY parent_id (parent_id),
  KEY parent_code (parent_code)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='ОКНПО начального профессионального образования';

ALTER TABLE `class_oknpo`
  ADD CONSTRAINT class_oknpo_ibfk_1 FOREIGN KEY (parent_id) REFERENCES class_oknpo (id);