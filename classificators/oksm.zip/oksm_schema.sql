CREATE TABLE class_country (
  id smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'pk',
  `name` varchar(255) NOT NULL COMMENT 'Наименование страны',
  full_name varchar(255) DEFAULT NULL COMMENT 'Полное наименование страны',
  number_code varchar(4) NOT NULL COMMENT 'Числовой код',
  alfa2 varchar(2) NOT NULL COMMENT 'Код альфа-2',
  alfa3 varchar(3) NOT NULL COMMENT 'Код альфа-3',
  visible tinyint(4) NOT NULL DEFAULT '1' COMMENT 'Видимость',
  `comment` varchar(255) DEFAULT NULL COMMENT 'Комментарий',
  PRIMARY KEY (id),
  UNIQUE KEY number_code (number_code),
  UNIQUE KEY alfa2 (alfa2),
  UNIQUE KEY alfa3 (alfa3)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Общероссийский классификатор стран мира ОКСМ';
