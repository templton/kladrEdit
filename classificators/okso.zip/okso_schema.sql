--
-- Структура таблицы 'class_okso'
--

CREATE TABLE class_okso (
  id smallint(11) NOT NULL auto_increment COMMENT 'PK',
  `name` varchar(512) NOT NULL COMMENT 'Наименование',
  `code` varchar(20) NOT NULL COMMENT 'Код',
  parent_id smallint(11) default NULL COMMENT 'Вышестоящий объект',
  parent_code varchar(20) default NULL COMMENT 'Код вышестоящего объекта',
  node_count smallint(6) NOT NULL default '0' COMMENT 'Количество вложенных в текущую ветку',
  PRIMARY KEY  (id),
  KEY parent_id (parent_id),
  KEY parent_code (parent_code)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Общероссийский классификатор специальностей по образованию' AUTO_INCREMENT=901 ;

-- --------------------------------------------------------

--
-- Структура таблицы 'class_okso_qual'
--

CREATE TABLE class_okso_qual (
  id smallint(6) NOT NULL auto_increment,
  class_okso_id smallint(6) NOT NULL,
  class_okso_qual_type_id smallint(6) NOT NULL,
  class_okso_qual_code1_id tinyint(4) NOT NULL COMMENT 'Уровень образования',
  class_okso_qual_code2_id tinyint(4) NOT NULL COMMENT 'Уровень квалификации',
  PRIMARY KEY  (id),
  UNIQUE KEY class_okso_id (class_okso_id,class_okso_qual_type_id),
  KEY class_okso_qual_type_id (class_okso_qual_type_id),
  KEY class_okso_qual_code1_id (class_okso_qual_code1_id),
  KEY class_okso_qual_code2_id (class_okso_qual_code2_id)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Связка мн-мн между ОКСО и квалификациями' AUTO_INCREMENT=1359 ;

-- --------------------------------------------------------

--
-- Структура таблицы 'class_okso_qual_code1'
--

CREATE TABLE class_okso_qual_code1 (
  id tinyint(4) NOT NULL COMMENT 'id',
  `name` varchar(128) NOT NULL COMMENT 'Уровень образования',
  PRIMARY KEY  (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='1 разряд кода квалификации (уровень образования)';

-- --------------------------------------------------------

--
-- Структура таблицы 'class_okso_qual_code2'
--

CREATE TABLE class_okso_qual_code2 (
  id tinyint(4) NOT NULL auto_increment COMMENT 'id',
  `code` tinyint(4) NOT NULL COMMENT 'Код уровня квалификации',
  `name` varchar(128) NOT NULL COMMENT 'Уровень квалификации',
  class_okso_qual_code1_id tinyint(4) NOT NULL COMMENT 'Уровень образования',
  PRIMARY KEY  (id),
  KEY class_okso_qual_code1_id (class_okso_qual_code1_id)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='2 разряд кода квалификации (уровень квалификации)' AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Структура таблицы 'class_okso_qual_type'
--

CREATE TABLE class_okso_qual_type (
  id smallint(6) NOT NULL auto_increment,
  `code` varchar(512) default NULL COMMENT 'Код квалификации',
  `name` varchar(512) NOT NULL COMMENT 'Квалификация',
  PRIMARY KEY  (id)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='ОКСО Квалификация' AUTO_INCREMENT=579 ;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `class_okso`
--
ALTER TABLE `class_okso`
  ADD CONSTRAINT class_okso_ibfk_1 FOREIGN KEY (parent_id) REFERENCES class_okso (id);

--
-- Ограничения внешнего ключа таблицы `class_okso_qual`
--
ALTER TABLE `class_okso_qual`
  ADD CONSTRAINT class_okso_qual_ibfk_4 FOREIGN KEY (class_okso_id) REFERENCES class_okso (id),
  ADD CONSTRAINT class_okso_qual_ibfk_1 FOREIGN KEY (class_okso_qual_type_id) REFERENCES class_okso_qual_type (id),
  ADD CONSTRAINT class_okso_qual_ibfk_2 FOREIGN KEY (class_okso_qual_code1_id) REFERENCES class_okso_qual_code1 (id),
  ADD CONSTRAINT class_okso_qual_ibfk_3 FOREIGN KEY (class_okso_qual_code2_id) REFERENCES class_okso_qual_code2 (id);

--
-- Ограничения внешнего ключа таблицы `class_okso_qual_code2`
--
ALTER TABLE `class_okso_qual_code2`
  ADD CONSTRAINT class_okso_qual_code2_ibfk_1 FOREIGN KEY (class_okso_qual_code1_id) REFERENCES class_okso_qual_code1 (id);
